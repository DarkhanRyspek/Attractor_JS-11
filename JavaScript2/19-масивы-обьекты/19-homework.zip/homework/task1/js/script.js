
const yodaSays = ["on JavaScript", "programming ", "I like "];
const message = yodaSays[2] + ' ' + yodaSays[1] + ' ' + yodaSays[0] + '.';

console.log(message);
/*
Задание 1
Дан массив:
const yodaSays = ["on JavaScript", "programming ", "I like "];
С помощью обращения к элементам массива составьте правильную строку и выведите ее на экран.
Указания:
Сдавать в виде HTML-файла.
*/