//task-1
alert("Задание-1");
const mainQuestion = prompt("У квадратного стола отпилили один угол. Сколько теперь углов у него стало?").toLowerCase();
if ((mainQuestion === '5') || (mainQuestion === 'five')) {
    alert('Ответ корректный!');
} else {
    alert('Ответ неправельный!')
}
