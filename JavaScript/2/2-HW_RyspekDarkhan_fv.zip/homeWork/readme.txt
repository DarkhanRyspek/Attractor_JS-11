1- следовал шаблону и ТЗ.
2- В секции "info" в блоке "info_block" использовал Flex
    - у меня возникли проблемы с картинкой из-за того что у них разные размеры;
    - учитель рекомендовал изменить размер самой картинки для выравнивания, так как flex позиционирование пройдем позже.




ТЗ к макету
Информация к дизайну:

Шрифт: arial 
ширина контентной части страницы: 1008px

Шапка
высота шапки - 62px  цвет фона: #02918c  
Логотип - нужно вставить картинкой завернутой в ссылку:  a > img

Промо-блок:
картинку можно вставить в html через тег <img>

Блок About me:
Заголовок:  #02918c,  46px,  bold
текст под заголовком: 16px,  #7e8287
заголовок в айтемах: 18px, bold, #7e8287
текст в айтемах: 14px normal #7e8287 высота строки 21px

Футер:
высота: 79px   фон: #000   текст: #7e8287 12px normal

Текст:
About me 
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat duis aute irure dolor.
Title goes here
onsectetur adipisicing elit, sedo eiusmod tempor incidi et dolorerserss eerhfre mag.
© Myfolio 

